# Bioinformatics Pipeline Results Export

Export Date: 2025-09-20 10:10:08
Pipeline Version: 1.0.0
Total Stages: 17
Overall Success Rate: 91.1%

## Contents:
- fasta_exports/: Sequence files in FASTA format
- csv_exports/: Performance and quality metrics
- json_exports/: Complete structured data
- visualizations/: Analysis plots and charts
- reports/: Summary reports and documentation
